using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyFirstWebApp.Pages.Employees
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
